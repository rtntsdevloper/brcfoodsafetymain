<?php
$tid = $_GET['tid'];
$access = $_SESSION['access'];
if ($access == "Auditor") {
	$sq = mysqli_query($con, "select * from tblauditor where name='$user'");
	$qu = mysqli_fetch_array($sq);
} else if ($access == "Auditee") {
	$sq = mysqli_query($con, "select * from tblauditee where name='$user'");
	$qu = mysqli_fetch_array($sq);
}

$sq2 = mysqli_query($con, "select * from dailychecks where id='$tid'");
$qu2 = mysqli_fetch_array($sq2);



?>

<div class="main-content">
	<div class="breadcrumb">
		<h1 class="mr-2"><?php echo $headingname; ?></h1>
		<ul>
			<li><a href="">Home</a></li>
			<li><?php echo $qu2['name']; ?></li>
		</ul>
	</div>


	<script language="javascript">
		function cal() {
			var d1 = document.getElementById("d1").value;
			var d2 = document.getElementById("d2").value;
			var t2 = document.getElementById("t2").value;
			var pid2 = document.getElementById("pid2").value;


			if (d1 == "" || d2 == "") {
				document.getElementById("sd1").innerHTML = "* Please select both date options";
			} else {

				$.post("mlmeats/dailysort", {
						d1: d1,
						d2: d2,
						t2: t2,
						pid2: pid2

					},
					function(data) {
						
							$("#tbdata").html(data);
						
					});

			}
		}
	</script>

	<div class="row mb-12">
		<div class="col-md-12 mb-12">
			<div class="card text-left">
				<div class="card-body">

					<div class="row">

						<div class="col-12"><label for="cc-exp" class="control-label mb-1" id="sd1" style="color:#FF0000"></label>
						</div>
						<div class="col-md-4 col-sm-6">
							<label for="cc-exp" class="control-label mb-1">Date From</label>
							<div class="input-group">

								<input type="date" name="d1" id="d1" class="form-control" />
							</div>
						</div>

						<div class="col-md-4 col-sm-6">
							<label for="cc-exp" class="control-label mb-1"> Date To</label>
							<div class="input-group">

								<input type="date" name="d2" id="d2" class="form-control" />
							</div>
						</div>



						<input type="hidden" name="t2" id="t2" class="form-control" value="<?php echo $tid;?>">
						<input type="hidden" name="pid2" id="pid2" class="form-control" value="<?php echo $_GET['id2'];?>">

						<div class="col-md-2 col-sm-6" style="margin:10px">
							<label for="cc-exp" class="control-label mb-1"></label>
							<div class="input-group">
								<button class="btn btn-info" style="float:right" onclick="return cal();">
									<li class="fa fa-list"></li> Select & Go
								</button>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="row mb-12">
		<div class="col-md-12 mb-12">
			<div class="card text-left">
				<div class="card-body">

					<a href="admin.php?id=dailycheckksdetail&id2=<?php echo $_GET['id2']; ?>"><button class="btn btn-success" style="float:right; margin-left:15px; margin-bottom:10px">Go Back</button></a>

					<a href="admin.php?id=dailycheckks1&tid=<?php echo $tid; ?>&id2=<?php echo $_GET['id2']; ?>"><button class="btn btn-success" style="float:right; margin-left:15px;margin-bottom:10px">Attempt StartUp Checks</button></a>

					<div class="table-responsive" id="tbdata">
						<table class="display table table-striped table-bordered" id="zero_configuration_table" style="width:100%">
							<thead>
								<tr>
									<th>#</th>
									<th>Name</th>
									<th>Date</th>
									<th><?php echo $qu2['name']; ?></th>
									<th>Closing Checks</th>

								</tr>
							</thead>
							<tbody>
								<?php

								$sql = mysqli_query($con, "select * from dailycheckss where name='$tid' ORDER BY `date` DESC");
								$i = 0;
								while ($row = mysqli_fetch_array($sql)) {
									$i++;
									$gh = mysqli_query($con, "select * from dailychecks where id='$row[name]'");
									$gh1 = mysqli_fetch_array($gh);

								?>
									<tr>
										<td><?php echo $i; ?></td>
										<td><?php echo $gh1['name']; ?></td>
										<td><?php echo date("d-m-Y", strtotime($row['date'])); ?></td>

										<td>
											<a href="admin.php?id=dailycheckks3&sno=<?php echo $row['id']; ?>&tid=<?php echo $tid; ?>&id2=<?php echo $_GET['id2']; ?>">
												<button class="btn btn-info">View Report</button></a>
										</td>
										<td>
											<?php
											if ($row['name1'] == "2") {
											?>
												<a href="admin.php?id=dailycheckks4&sno=<?php echo $row['id']; ?>&tid=<?php echo $tid; ?>&id2=<?php echo $_GET['id2']; ?>">
													<button class="btn btn-warning">View Report</button></a>
											<?php
											} else {
											?>
												<a href="admin.php?id=closingcheckks1&tid=<?php echo $tid; ?>&sno=<?php echo $row['id']; ?>&id2=<?php echo $_GET['id2']; ?>">
													<button class="btn btn-danger"> Attempt Closing Checks</button></a>
											<?php
											}
											?>
										</td>

									</tr>
								<?php
								}
								?>
							</tbody>
						</table>
					</div>

				</div>
			</div>
		</div>